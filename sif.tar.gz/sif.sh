#/bin/bash

export NODE_HOME=/home/ubuntu/cardano-my-node
export CARDANO_NODE_SOCKET_PATH=/home/ubuntu/cardano-my-node/db/socket
export CARDANO_NETWORK=MAINNET

echo $1
cd $1
sudo touch /var/log/sif.log
sudo chown ubuntu: /var/log/sif.log
./sif >> /var/log/sif.log 2>&1
